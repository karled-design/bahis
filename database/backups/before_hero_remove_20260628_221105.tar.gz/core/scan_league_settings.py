from __future__ import annotations

import threading
from typing import Any, TypedDict

__all__ = (
    "SHARP_LEAGUE_CATALOG",
    "ScanLeagueSettings",
    "build_scan_leagues_payload",
    "get_enabled_sharp_sport_keys",
    "get_leagues_per_scan",
    "get_scan_league_settings",
    "update_scan_league_settings",
)

_PRIORITY_SPORT_KEY = "soccer_turkey_super_league"
_DEFAULT_LEAGUES_PER_SCAN = 3
_MIN_LEAGUES_PER_SCAN = 1
_MAX_LEAGUES_PER_SCAN = 6


class _LeagueCatalogEntry(TypedDict):
    sport_key: str
    label: str
    tip: str


SHARP_LEAGUE_CATALOG: tuple[_LeagueCatalogEntry, ...] = (
    {
        "sport_key": "soccer_fifa_world_cup",
        "label": "FIFA World Cup",
        "tip": "Milli takim maclari. Panelden acilir; varsayilan taramada kapali.",
    },
    {
        "sport_key": "soccer_turkey_super_league",
        "label": "Turkiye Super Lig",
        "tip": "Turk ligleri. Sezon acikken Nesine maclari ile eslesir.",
    },
    {
        "sport_key": "soccer_uefa_champs_league",
        "label": "UEFA Champions League",
        "tip": "Sampiyonlar Ligi referans oranlari.",
    },
    {
        "sport_key": "soccer_epl",
        "label": "Premier League",
        "tip": "Ingiltere Premier League.",
    },
    {
        "sport_key": "soccer_spain_la_liga",
        "label": "La Liga",
        "tip": "Ispanya La Liga.",
    },
    {
        "sport_key": "soccer_germany_bundesliga",
        "label": "Bundesliga",
        "tip": "Almanya Bundesliga.",
    },
    {
        "sport_key": "soccer_italy_serie_a",
        "label": "Serie A",
        "tip": "Italya Serie A — genisletilmis tarama.",
    },
    {
        "sport_key": "soccer_france_ligue_one",
        "label": "Ligue 1",
        "tip": "Fransa Ligue 1 — genisletilmis tarama.",
    },
    {
        "sport_key": "soccer_uefa_europa_league",
        "label": "UEFA Europa League",
        "tip": "Avrupa Ligi referans oranlari.",
    },
    {
        "sport_key": "soccer_netherlands_eredivisie",
        "label": "Eredivisie",
        "tip": "Hollanda Eredivisie.",
    },
)

_VALID_SPORT_KEYS = frozenset(entry["sport_key"] for entry in SHARP_LEAGUE_CATALOG)
_DEFAULT_ENABLED_KEYS: tuple[str, ...] = tuple(
    entry["sport_key"]
    for entry in SHARP_LEAGUE_CATALOG
    if entry["sport_key"] != "soccer_fifa_world_cup"
)


class ScanLeagueSettings(TypedDict):
    leagues_per_scan: int
    enabled_sport_keys: list[str]


_LOCK = threading.Lock()
_STATE: ScanLeagueSettings = {
    "leagues_per_scan": _DEFAULT_LEAGUES_PER_SCAN,
    "enabled_sport_keys": list(_DEFAULT_ENABLED_KEYS),
}


def _clamp_leagues_per_scan(value: int) -> int:
    return max(_MIN_LEAGUES_PER_SCAN, min(_MAX_LEAGUES_PER_SCAN, int(value)))


def _normalize_enabled_keys(keys: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for entry in SHARP_LEAGUE_CATALOG:
        sport_key = entry["sport_key"]
        if sport_key in keys and sport_key not in seen:
            ordered.append(sport_key)
            seen.add(sport_key)
    if not ordered:
        return list(_DEFAULT_ENABLED_KEYS)
    return ordered


def get_scan_league_settings() -> ScanLeagueSettings:
    with _LOCK:
        return {
            "leagues_per_scan": int(_STATE["leagues_per_scan"]),
            "enabled_sport_keys": list(_STATE["enabled_sport_keys"]),
        }


def get_leagues_per_scan() -> int:
    with _LOCK:
        return int(_STATE["leagues_per_scan"])


def get_enabled_sharp_sport_keys() -> tuple[str, ...]:
    with _LOCK:
        return tuple(_STATE["enabled_sport_keys"])


def update_scan_league_settings(payload: dict[str, Any]) -> ScanLeagueSettings:
    if not isinstance(payload, dict):
        raise TypeError("payload must be a dict")

    with _LOCK:
        if "leagues_per_scan" in payload:
            raw = payload.get("leagues_per_scan")
            if isinstance(raw, bool) or not isinstance(raw, int):
                raise TypeError("leagues_per_scan must be an int")
            _STATE["leagues_per_scan"] = _clamp_leagues_per_scan(raw)

        if "enabled_sport_keys" in payload:
            raw_keys = payload.get("enabled_sport_keys")
            if not isinstance(raw_keys, list):
                raise TypeError("enabled_sport_keys must be a list")
            normalized: list[str] = []
            for item in raw_keys:
                if not isinstance(item, str):
                    raise TypeError("enabled_sport_keys items must be strings")
                key = item.strip()
                if key not in _VALID_SPORT_KEYS:
                    raise ValueError(f"unknown sport_key: {key}")
                if key not in normalized:
                    normalized.append(key)
            if not normalized:
                raise ValueError("at least one league must remain enabled")
            _STATE["enabled_sport_keys"] = normalized

        max_allowed = max(1, len(_STATE["enabled_sport_keys"]))
        if _STATE["leagues_per_scan"] > max_allowed:
            _STATE["leagues_per_scan"] = max_allowed

        return {
            "leagues_per_scan": int(_STATE["leagues_per_scan"]),
            "enabled_sport_keys": list(_STATE["enabled_sport_keys"]),
        }


def build_scan_leagues_payload() -> dict[str, Any]:
    settings = get_scan_league_settings()
    enabled = set(settings["enabled_sport_keys"])
    leagues: list[dict[str, Any]] = []
    for entry in SHARP_LEAGUE_CATALOG:
        sport_key = entry["sport_key"]
        leagues.append(
            {
                "sport_key": sport_key,
                "label": entry["label"],
                "tip": entry["tip"],
                "enabled": sport_key in enabled,
            }
        )
    return {
        "leagues_per_scan": settings["leagues_per_scan"],
        "min_leagues_per_scan": _MIN_LEAGUES_PER_SCAN,
        "max_leagues_per_scan": _MAX_LEAGUES_PER_SCAN,
        "enabled_count": len(settings["enabled_sport_keys"]),
        "leagues": leagues,
        "tip": (
            "Her taramada Odds API'den kac lig cekilecegini ve hangi liglerin aktif "
            "oldugunu belirler. Daha fazla lig = daha cok mac eslesmesi; API kotasi artar."
        ),
    }


def select_rotated_sharp_sport_keys(*, rotation_index: int) -> tuple[list[str], int]:
    """Pick sport keys for one sharp scan using enabled leagues and rotation."""
    enabled = list(get_enabled_sharp_sport_keys())
    if not enabled:
        enabled = list(_DEFAULT_ENABLED_KEYS)

    leagues_per_scan = min(get_leagues_per_scan(), len(enabled))
    selected: list[str] = []
    if _PRIORITY_SPORT_KEY in enabled:
        selected.append(_PRIORITY_SPORT_KEY)

    cursor = int(rotation_index)
    while len(selected) < leagues_per_scan:
        candidate = enabled[cursor % len(enabled)]
        cursor += 1
        if candidate in selected:
            if len(enabled) <= len(selected):
                break
            continue
        selected.append(candidate)

    return selected, cursor
