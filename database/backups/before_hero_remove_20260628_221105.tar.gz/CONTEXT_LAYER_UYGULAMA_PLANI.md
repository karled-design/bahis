# SQE-V1 — İstatistik + Bağlam Katmanı Uygulama Planı

> **Oluşturulma:** 2026-06-19  
> **Durum:** Faz 3 tamamlandı — Faz 4 opsiyonel  

## Gerçek maç ilkesi (tüm fazlar)

- Context, theory test ve API verisi **yalnızca gerçek maçlar** içindir.
- E-futbol, sanal lig, SRL, dry-run ve `match_quality=suspicious` kayıtları **cache'e ve analize alınmaz**.
- Theory backtest (Adım 6) yalnızca bitmiş **gerçek** maç skorları ve referans oranları ile çalışır.
> **İlgili dosyalar:** `scrapers/live_feed_gateway.py`, `scrapers/sharp_feed.py`, `core/scan_pipeline.py`

---

## Strateji özeti

| Hat | Amaç | Stake |
|-----|------|-------|
| **A — Value (mevcut)** | Nesine oranı referanstan iyi mi? | Evet |
| **B — Context (yeni)** | Gün içi maçlarda form, sakatlık, bağlam | Hayır (bilgi) veya EV ile birleşik |

**Kural:** Context katmanı canlı “Oyna önerisi”ne bağlanmadan önce `tools/theory_backtest.py` çıkış kriterlerini geçmelidir.

---

## Uygulama sırası (adım adım)

### FAZ 0 — Temel sağlamlaştırma

| # | Adım | Durum | Dosyalar | Kabul kriteri |
|---|------|-------|----------|---------------|
| **1** | Birleşik feed'e `event_id`, `commence_time`, `sport_key`, `league_name` ekle | `[x] Tamamlandı` | `sharp_feed.py`, `live_feed_gateway.py`, `UnifiedMatchFeed` | Snapshot'ta 4 alan dolu; `league_name` ≠ "Bilinmiyor" (sharp tarafında) |
| **2** | Soft–sharp eşleşme kalite skoru: oran oranı >3× ise `match_quality=suspicious` bayrağı | `[x] Tamamlandı` | `live_feed_gateway.py`, `scan_pipeline.py` | Şüpheli eşleşmeler funnel'de ayrı sayılır; aday listesine girmez |
| **3** | Context cache için SQLite şema taslağı (`context_cache` tabloları) | `[x] Tamamlandı` | `database/db_manager.py`, `database/context_cache.py` | Tablolar oluşur; boş cache ile sistem çalışır; sanal maç reddedilir |

---

### FAZ 1 — Theory Lab (Telegram yok)

| # | Adım | Durum | Dosyalar | Kabul kriteri |
|---|------|-------|----------|---------------|
| **4** | `core/context_features.py` — form, standings, H2H feature vektörü (**gerçek maç fixture örnekleri**) | `[x] Tamamlandı` | `core/context_features.py`, `tests/` | Unit test: gerçek fixture JSON → beklenen feature; sanal maç reddedilir |
| **5** | `core/context_score.py` — ağırlıklı skor kartı (−100…+100) | `[x] Tamamlandı` | `core/context_score.py`, `tests/` | Skor yönü tutarlı; overconfidence (>8% sharp sapma) cezalandırılır |
| **6** | `tools/theory_backtest.py` — walk-forward, Brier, paper ROI | `[x] Tamamlandı` | `tools/theory_backtest.py`, `core/theory_backtest.py` | Rapor üretir; EV-only vs EV+context karşılaştırması |
| **7** | Theory çıkış kararı: fusion canlıya bağlansın mı? | `[x] Onaylandi` | Bu dosya, `core/context_fusion.py` | Filtre modu aktif; baglam yoksa EV-only |

---

### FAZ 2 — Context Enricher

| # | Adım | Durum | Dosyalar | Kabul kriteri |
|---|------|-------|----------|---------------|
| **8** | `scrapers/context_feed.py` — API-Football istemci + agresif cache | `[x] Tamamlandı` | `scrapers/context_feed.py`, `.env` | Günlük kota bütçesi loglanır; cache hit oranı görülür |
| **9** | `core/team_resolver.py` — takım adı → API-Football team_id | `[x] Tamamlandı` | `core/team_resolver.py`, alias tablosu | Süper Lig + milli takım örnekleri çözülür |
| **10** | Günlük job: bugünün maçları → standings/H2H/injuries cache | `[x] Tamamlandı` | `bahis/main.py` veya ayrı thread | Panel/API'den "bugünün maçları" listelenir |
| **11** | `tools/context_diag.py` — günlük maç + skor raporu | `[x] Tamamlandı` | `tools/context_diag.py` | Terminal raporu; Telegram yok |

---

### FAZ 3 — Fusion + bildirim

| # | Adım | Durum | Dosyalar | Kabul kriteri |
|---|------|-------|----------|---------------|
| **12** | `scan_pipeline` genişletme: opsiyonel context + fusion kuralları | `[x] Tamamlandı` | `core/scan_pipeline.py`, `core/alert_context_line.py`, `bahis/main.py` | EV+context uyumlu → tier korunur; Telegram'da kisa baglam etiketi |
| **13** | Telegram: "Günün Analizi" şablonu + mevcut mesaja form satırı | `[ ] Bekliyor` | `notifiers/telegram_worker.py` | Stake=0 bilgi mesajı ayrı tier |
| **14** | Panel slider: "Bağlam filtresi" (Kapalı / Bilgi / EV birleşik) | `[x] Tamamlandı` | `operator_risk_settings.py`, `index.html`, `web_server.py` | Kayıt/yükleme çalışır |
| **15** | Pilot A/B: 2 hafta paper trade fusion açık/kapalı | `[x] Tamamlandı` | `core/paper_trade.py`, `index.html` | Karşılaştırma raporu panelde |

---

### FAZ 4 — Haber (opsiyonel, Faz 7 geçmezse ertelenir)

| # | Adım | Durum | Dosyalar | Kabul kriteri |
|---|------|-------|----------|---------------|
| **16** | Maçtan 2 saat önce sakatlık yenileme | `[ ] Bekliyor` | `context_feed.py` | Skor değişimi loglanır |
| **17** | RSS whitelist (max 5 resmi kaynak) — yapılandırılmış madde listesi | `[ ] Bekliyor` | `scrapers/news_feed.py` | LLM yok; madde listesi only |

---

## Şu anki adım

## Faz 3 tamamlandi (2026-06-19) ✅

**Adim 14 — Panel baglam modu**
- Kapali / Bilgi / EV+Filtre (3 dugme, otomatik kayit)
- Slider etiketleri sadelestirildi

**Adim 15 — Pilot A/B**
- Her tarama dongusu SQLite'a kaydedilir
- Panelde: EV-only (simule), Fusion sonrasi, Baglam elendi, Tarama sayisi

**Baglam modu ozeti**
| Mod | Telegram | Fusion | API enrich |
|-----|----------|--------|------------|
| Kapali | Etiket yok | Kapali | Kapali |
| Bilgi | Kisa satir | Kapali | Acik |
| EV+Filtre | Kisa satir | Acik | Acik |

---

**Tek cümle:** Stake=0 bilgi mesaji ayri tier (opsiyonel genisletme).

**Durum:** `[ ] Bekliyor — operatör onayı`

---

## Adım 12 tamamlandı (2026-06-19) ✅

**Yapılanlar:**
- [x] `core/alert_context_line.py`: tek satirlik inline etiket (`| Baglam: ev +9`)
- [x] `bahis/main.py`: WATCH/ACTION/HIGH mesajlarina eklendi
- [x] Baglam yokken mesaj **degismez** (regresyon yok)
- [x] Yeni satir eklenmez; mevcut oran satirina eklenir
- [x] `tests/test_alert_context_line.py`

**Ornek:**
```
Nesine=2.20 | Referans=2.05 | EV=%7.32 | SharpBook=3 | Baglam: ev +9
```

---

### Adım 12 — Fusion + Telegram (TAMAMLANDI)

**Tek cümle:** Fusion sonuclarini Telegram mesajlarina yansitma.

**Durum:** `[x] Tamamlandı`

---

## Adım 11 tamamlandı (2026-06-19) ✅

**Yapılanlar:**
- [x] `core/context_diag.py`: tarih filtresi, event dedupe, MS1/X/MS2 skor + fusion durumu
- [x] `tools/context_diag.py`: CLI (`--source fixture|live`, `--date`, `--enrich`, `--json`)
- [x] `tests/test_context_diag.py`: 6 test
- [x] Varsayilan fixture modu (ag/API gerektirmez)

**Guvenlik:**
- Sanal/supheli maclar rapora alinmaz
- `--enrich` yalnizca live + API key ile
- Telegram baglantisi yok

**Kullanim:**
```bash
PYTHONPATH=. python3 tools/context_diag.py --source fixture
PYTHONPATH=. python3 tools/context_diag.py --source live --date 2026-06-19
PYTHONPATH=. python3 tools/context_diag.py --source live --enrich   # API_FOOTBALL_KEY gerekir
```

---

### Adım 11 — Context diag aracı (TAMAMLANDI)

**Tek cümle:** Terminalden bugunun maclarini baglam skoru ile raporlayacagiz; Telegram yok.

**Durum:** `[x] Tamamlandı`

---

## Adım 10 tamamlandı (2026-06-19) ✅

**Yapılanlar:**
- [x] `bahis/main.py`: tarama dongusune `enrich_match_feed_safely` eklendi (feed sonrasi, pipeline oncesi)
- [x] `config/settings.py`: `CONTEXT_ENRICH_MODE=auto|on|off` (varsayilan `auto`)
- [x] `scrapers/context_feed.py`: event_id dedupe, guvenli wrapper, dry-run atlama
- [x] Panel satirlarina `has_context` bayragi
- [x] Tarama ozetine `context_bundle` ve `context_api_req`
- [x] `tests/test_context_enrich_integration.py`

**Guvenlik:**
- Dry-run modda enrich kapali
- API key yoksa enrich kapali (EV-only korunur)
- Hata olursa orijinal feed ile devam
- Ayni macin MS1/X/MS2 satirlari tek API oturumu paylasir

---

### Adım 10 — Günlük context job (TAMAMLANDI)

**Tek cümle:** Canli tarama dongusune `enrich_matches_with_context` baglanacak; bugunun maclari cache'den beslenecek.

**Durum:** `[x] Tamamlandı`

---

## Adım 9 tamamlandı (2026-06-19) ✅

**Yapılanlar:**
- [x] `core/team_resolver.py`: alias + canonical + sinirli fuzzy eslestirme
- [x] `config/team_aliases.json`: Super Lig (GS, FB, BJK, TS...) + milli (Turkiye, Almanya, Fransa)
- [x] `scrapers/context_feed.py`: alias tabanli fixture eslestirme (fuzzy fallback korundu)
- [x] `tests/test_team_resolver.py`: 10 test
- [x] `tests/test_context_feed.py`: "GS - FB" kisaltma testi

**Guvenlik:**
- Lig disi capraz eslestirme yok (GS + EPL → None)
- Milli takimlar yalnizca `international` veya fifa/world/euro sport_key ile
- Canli pipeline (`main.py`) henuz baglanmadi

---

### Adım 9 — Takım adı çözümleyici (TAMAMLANDI)

**Tek cümle:** Odds API takım adlarını API-Football team_id ile eşleştireceğiz; fixture eşleşme oranı artacak.

**Durum:** `[x] Tamamlandı`

---

## Adım 8 tamamlandı (2026-06-19) ✅

**Yapılanlar:**
- [x] `scrapers/context_feed.py`: API-Football v3 istemci (fixtures, standings, injuries, H2H)
- [x] `database/context_cache.py`: standings/injuries/H2H/bundle read-write
- [x] `database/db_manager.py`: `run_context_cache_operation`
- [x] `config/settings.py`: `API_FOOTBALL_KEY` (opsiyonel; yoksa sistem kırılmaz)
- [x] `tests/test_context_feed.py`: mock HTTP ile 7 test
- [x] Lig eşlemesi: TR 203, EPL 39, La Liga 140, Bundesliga 78, UCL 2

**Bilinçli erteleme (Adım 10):** `main.py` / canlı feed'e `enrich_matches_with_context` bağlanmadı — operatör onayı bekleniyor.

**Kullanım (test/diag):**
```bash
PYTHONPATH=. python3 -c "
from scrapers.context_feed import enrich_matches_with_context
m = [{'event_id':'x','sport_key':'soccer_turkey_super_league','match_name':'Galatasaray - Fenerbahce','commence_time':'2026-06-19T18:00:00Z','match_quality':'ok'}]
print(enrich_matches_with_context(m))  # API_FOOTBALL_KEY gerekir
"
```

---

### Adım 8 — API-Football context feed (TAMAMLANDI)

**Tek cümle:** Gercek mac istatistiklerini API-Football'dan cekip cache'e yazacagiz; fusion filtresi baglam verisi geldiginde otomatik devreye girecek.

**Durum:** `[x] Tamamlandı`

---

## Adım 7 kararı (2026-06-19) — ONAYLANDI

**Operatör:** Fusion **filtre modu** onaylandi (`CONTEXT_FUSION_MODE=filter`).

| Karar | Detay |
|-------|--------|
| **Mod** | ACTION/HIGH yalnizca baglam market yonunu destekliyorsa gecer |
| **Baglam yokken** | Mevcut EV-only davranis korunur (regresyon yok) |
| **Amaç** | Theory-lab'de kanitlanan FP azaltma mantigi; kazanma kalitesi > bildirim sayisi |
| **Sinir** | Fixture gate gecisi canli kanit degil; Adim 8-10 veri gelince tam etki |

**Uygulanan kod:**
- [x] `core/context_fusion.py`
- [x] `scan_pipeline.py` → `context_filter` sayaci
- [x] `config/settings.py` → `CONTEXT_FUSION_MODE=filter`
- [x] `tests/test_context_fusion.py`

---

## Tamamlanan adımlar

### Adım 6 — Theory backtest ✅

EV-only vs EV+context karşılaştırmalı theory-lab aracı; canlı pipeline değişmedi.

**Yapılanlar:**
- [x] `core/theory_backtest.py`: metrikler, fusion gate, walk-forward log
- [x] `tools/theory_backtest.py`: CLI rapor
- [x] `tests/fixtures/theory/backtest_cases.json`: 8 gerçek takım senaryosu (sanal yok)
- [x] `tests/test_theory_backtest.py`: 6 test

**Komut:**
```bash
PYTHONPATH=. python3 tools/theory_backtest.py
```

**Durum:** `[x] Tamamlandı — 2026-06-19`

### Adım 5 — Context skor kartı ✅

Feature'lardan ev sahibi/deplasman bağlam skoru; sharp sapması >%8 ise skor zayıflatılır.

**Yapılanlar:**
- [x] `core/context_score.py`: `score_home_bias`, `score_context_for_market`
- [x] Overconfidence dampening (gap > 0.08)
- [x] `tests/test_context_score.py`: 7 test
- [x] Canlı scan/Telegram **değiştirilmedi**

**Durum:** `[x] Tamamlandı — 2026-06-19`

### Adım 4 — Context feature vektörü ✅

Gerçek takım adlarıyla fixture JSON'dan sayısal feature çıkarımı; sanal/şüpheli maç reddedilir.

**Yapılanlar:**
- [x] `core/context_features.py`: standings, form, H2H, sakatlık → `ContextFeatures`
- [x] `tests/fixtures/context/tur_super_lig_gs_fb.json`: sabit test yükü (canli API degil)
- [x] `tests/test_context_features.py`: 5 test

**Durum:** `[x] Tamamlandı — 2026-06-19`

### Adım 3 — Context cache SQLite şeması ✅

Fixtures, standings, form, sakatlık ve H2H için cache tabloları oluşturuldu; yalnızca gerçek maçlar yazılabilir.

**Yapılanlar:**
- [x] `database/context_cache.py`: 5 tablo + `is_cacheable_real_match` guard
- [x] `database/db_manager.py`: `init_db` içinde şema; `get_context_cache_stats`
- [x] `tests/test_context_cache.py`: şema + gerçek maç / sanal red testleri

**Durum:** `[x] Tamamlandı — 2026-06-19`

### Adım 2 — Soft–sharp eşleşme kalite skoru ✅

Oran oranı >3× olan eşleşmeler `match_quality=suspicious` ile işaretlenip aday listesinden elendi.

**Yapılanlar:**
- [x] `core/match_filters.py`: `is_suspicious_odds_pair`, `is_suspicious_match_record`
- [x] `live_feed_gateway.py`: birleşik kayda `match_quality` (`ok` / `suspicious`)
- [x] `scan_pipeline.py`: `suspicious_match` funnel sayacı
- [x] `main.py`, `telegram_worker.py`, `feed_diag.py`: funnel raporuna eklendi
- [x] `tests/test_context_metadata.py`: şüpheli eşleşme testleri

**Durum:** `[x] Tamamlandı — 2026-06-19`

### Adım 1 — Birleşik feed metadata zenginleştirme ✅

Sharp feed'den `event_id`, `commence_time`, `sport_key`, `league_name` birleşik kayda eklendi.

**Yapılanlar:**
- [x] `sharp_feed.py`: Odds API event metadata parse
- [x] `live_feed_gateway.py`: birleşim + sharp lig adı önceliği
- [x] `dry_run_feed.py`: mock metadata
- [x] `tests/test_context_metadata.py`: metadata + merge testleri

**Durum:** `[x] Tamamlandı — 2026-06-19`

---

## Theory test çıkış kriterleri (Adım 7)

Canlı fusion için **en az biri** sağlanmalı:

1. Context, EV-pozitif sette false positive oranını **≥ %15** azaltır  
2. Paper ROI (slippage %1.5 dahil) **≥ %0.5** mutlak iyileşme gösterir  

Sağlanmazsa → Context yalnızca **bilgi hattı** (stake yok).

---

## İlerleme günlüğü

| Tarih | Adım | Sonuç |
|-------|------|-------|
| 2026-06-19 | Plan oluşturuldu | Adım 1 onay bekliyor |
| 2026-06-19 | Adım 1 tamamlandı | Metadata alanları + test_context_metadata.py |
| 2026-06-19 | Adım 2 tamamlandı | suspicious_match bayrağı + funnel + 17 test |
| 2026-06-19 | Adım 3 tamamlandı | context_cache şeması + gerçek maç guard + 6 test |
| 2026-06-19 | Adım 4 tamamlandı | context_features + GS-FB fixture + 5 test |
| 2026-06-19 | Adım 5 tamamlandı | context_score + overconfidence guard + 7 test |
| 2026-06-19 | Adım 6 tamamlandı | theory_backtest CLI + 8 case fixture + 6 test |
| 2026-06-19 | Adım 7 onaylandi | context_fusion filter modu scan_pipeline'a baglandi |

---

## Onay protokolü

Her adım tamamlandığında:
1. Bu dosyada adım `[x] Tamamlandı` olarak işaretlenir
2. İlerleme günlüğüne satır eklenir
3. Sonraki adım için operatör onayı istenir

**Sıradaki onay sorusu:** Adım 8 (API-Football context feed) uygulansın mı?
